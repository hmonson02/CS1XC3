 
/**
 * @file course.h
 * @author Hayley Monson
 * @brief Course catalog for managing courses, including course name, code, classlist, and enrollment.
 * @version 0.1
 * @date 2022-04-09
 * 
 * @copyright Copyright (c) 2022
 * 
 */



#include "student.h"
#include <stdbool.h>


/**
 * Course type stores a course with a course name, a course cose, an array of students, and a total number students.
 *
 */

typedef struct _course 
{
  char name[100]; /**< course name */
  char code[10]; /**< course code */
  Student *students; /**< classlist */
  int total_students; /**< number of enrolled students */
} Course;

void enroll_student(Course *course, Student *student);
void print_course(Course *course);
Student *top_student(Course* course);
Student *passing(Course* course, int *total_passing);


