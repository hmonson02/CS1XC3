#include "course.h"
#include <stdlib.h>
#include <stdio.h>

/**
 * @brief Adds a student along with all of their information to the existing classlist of a course. We begin by
 * incrementing the class size by 1. If this student is the first one in the course we initialize memory space
 * to store that student's info. If the class size is not 1, we reallocate enough memory for one more student's
 * information. Then we add the student to the end of the classlist.
 * 
 * @param course a course type datum including a course name, code, classlist, and total enrollement
 * @param student a student typethe classlist, including the student's first and last name, their student id, their
 * grades, and the number of grades they have recieved.
 *
 * @return void
 */
void enroll_student(Course *course, Student *student)
{
  course->total_students++;
  if (course->total_students == 1) 
  {
    course->students = calloc(1, sizeof(Student));
  }
  else 
  {
    course->students = 
      realloc(course->students, course->total_students * sizeof(Student)); 
  }
  course->students[course->total_students - 1] = *student;
}

/**
 * @brief Prints the information about a course stored in the course struct, including the course name, course code, total enrollment, and classlist. We begin by printing the course name, the course code, and the total number of students using printf(). Then we create a loop and increment through the classlist, using the print_student() function defined in student.c, which prints out all the information stored in the student datatype for that student, including first and last name, student id, student grades, and the student's average across all their grades.
 *
 * 
 * @param course takes in a course to print out information about it
 * @return void
 */
void print_course(Course* course)
{
  printf("Name: %s\n", course->name);
  printf("Code: %s\n", course->code);
  printf("Total students: %d\n\n", course->total_students);
  printf("****************************************\n\n");
  for (int i = 0; i < course->total_students; i++) 
    print_student(&course->students[i]);
}


/**
 * @brief Prints out the studnt with the highest average across all grades in the course. It does so by incrementing through every student in the class, and comparing averages to find the highest one by the times the classlist is done being passed through. We create a loop which goes through all the students in the course and averages the ith student's grades using the average() function defined in student.c. If the average of student i's grades are larger than the current value stored in max value, that student's average now becomes max_average.
 * 
 * @param course  takes in a course type datum including its course name, code, classlist, and total enrollement
 * @return Student*, the top student and their information
 */


Student* top_student(Course* course)
{
  if (course->total_students == 0) return NULL;
 
  double student_average = 0;
  double max_average = average(&course->students[0]);
  Student *student = &course->students[0];
 
  for (int i = 1; i < course->total_students; i++)
  {
    student_average = average(&course->students[i]);
    if (student_average > max_average) 
    {
      max_average = student_average;
      student = &course->students[i];
    }   
  }

  return student;
}


/**
 * @brief Creates a list of students who are presently passing the course. We loop through the classlist, calculate the average of the student using the average() function defined in student.c, and add one to the passing total (count++) if that student has an average greater than or equal to 50. After this is done, we allocate the number of bytes of the student datatype times the number of students who passed using callloc(), so we have sufficient space to store all the passing students and their information in memory. Then we loop through the students and add each passing student's information to the array of passing students.
 * 
 * @param course takes in a course datatype including its course name, code, classlist, and total enrollement.
 * @param total_passing  an integer pointer which will store the total number of passing students
 * @return Student* the array of passing students
 */
Student *passing(Course* course, int *total_passing)
{
  int count = 0;
  Student *passing = NULL;
  
  for (int i = 0; i < course->total_students; i++) 
    if (average(&course->students[i]) >= 50) count++;
  
  passing = calloc(count, sizeof(Student));

  int j = 0;
  for (int i = 0; i < course->total_students; i++)
  {
    if (average(&course->students[i]) >= 50)
    {
      passing[j] = course->students[i];
      j++; 
    }
  }

  *total_passing = count;

  return passing;
}
