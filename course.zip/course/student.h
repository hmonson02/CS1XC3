/**
 * @file student.h
 * @author Hayley Monson
 * @date 2022-04-08
 * @brief Student catalog for managing students, including student first and last name, student ID, and student grades
 */

/**
 * Student type stores a student's information including student first and last name, student ID,
 * student grades, and the number of grades entered for that student.
 * 
 */

typedef struct _student 
{ 
  char first_name[50]; /**< first name */
  char last_name[50]; /**< last name */
  char id[11]; /**< student id */
  double *grades; /**< student grades */
  int num_grades; /**< number of student grades*/
} Student;

void add_grade(Student *student, double grade);
double average(Student *student);
void print_student(Student *student);
Student* generate_random_student(int grades); 
