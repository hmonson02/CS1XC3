/**
 * @file student.c
 * @author Hayley Monson
 * @brief contains the functions for student management including adding a grade to the list of grades
 * for that student, calculating the average of the student's grades, printing the student's information,
 * and generating random students and their data.
 * @version 0.1
 * @date 2022-04-09
 * 
 * @copyright Copyright (c) 2022
 * 
 */



#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "student.h"

/**
 * Adds a grade to the list of the student's grades. First we increment the number of grades that student has stored by one. If this is the first grade being added for the student we allocated 
 * enough memory to store one grade using calloc(). If the student has more than one grade we reallocate memory using realloc() to store all the other grades and the new grade. Finally, we put the new grade in the last position of 
 * the grades array.
 * 
 * @param student takes in a student who's grade list we want to add to
 * @param grade takes in a grade to add to the student's information
 * @return void
 * 
 */

void add_grade(Student* student, double grade)
{
  student->num_grades++;
  if (student->num_grades == 1) student->grades = calloc(1, sizeof(double));
  else 
  {
    student->grades = 
      realloc(student->grades, sizeof(double) * student->num_grades);
  }
  student->grades[student->num_grades - 1] = grade;
}

/**
 * Calculates the average of the student's grades. We loop through the student's grades and add each grade to the total sum of grades. Then we
 * divide the total sum of grades stored in total by the number of grades that student had entered, stored in student->num_grades, to calculate
 * the student's average.
 * 
 * @param student takes in a student
 * @return double
 */

double average(Student* student)
{
  if (student->num_grades == 0) return 0;

  double total = 0;
  for (int i = 0; i < student->num_grades; i++) total += student->grades[i];
  return total / ((double) student->num_grades);
}

/**
 * Prints student information in the student datatype including first and last name, student id, grades, and average. We first print out the student's name as: first, last.
 * Then we print the student's student id. We loop through the student's grades and print out each grade, and finally we print out the student's average using the average() method
 * defined above in this file.
 * 
 * @param student function takes in a student
 * @return void
 * 
 */

void print_student(Student* student)
{
  printf("Name: %s %s\n", student->first_name, student->last_name); 
  printf("ID: %s\n", student->id); 
  printf("Grades: ");
  for (int i = 0; i < student->num_grades; i++) 
    printf("%.2f ", student->grades[i]);
  printf("\n");
  printf("Average: %.2f\n\n", average(student));
}

/**
 * Generates a random student and their information. We begin by using calloc() to allocate enough memory to store one student. We then randomly pick
 * a first and last name randomly from the preset lists of 24 first and last names and store these in new_student->first_name and new_student->last_name respectively
 * using strcpy(). Then we create a loop which randomly generates a 10 digit student id and adds the null terminator at the end. Finally, we create a loop which
 * randomly generates doubles below 100 for the number of input grades and adds them to the student's list of grades.
 * 
 * @param grades input is a number of grades to randomly generate for the student
 * @return Student* 
 */


Student* generate_random_student(int grades)
{
  char first_names[][24] = 
    {"Shahrzad", "Leonti", "Alexa", "Ricardo", "Clara", "Berinhard", "Denzel",
     "Ali", "Nora", "Malcolm", "Muhammad", "Madhu", "Jaiden", "Helena", "Diana",
     "Julie", "Omar", "Yousef",  "Amir", "Wang", "Li", "Zhang", "Fen", "Lin"};

  char last_names[][24] = 
   {"Chen", "Yang", "Zhao", "Huang", "Brown", "Black", "Smith", "Williams", 
    "Jones", "Miller", "Johnson", "Davis", "Abbas", "Ali", "Bakir", "Ismat", 
    "Khalid", "Wahed", "Taleb", "Hafeez", "Hadid", "Lopez", "Gonzalez", "Moore"};
 
  Student *new_student = calloc(1, sizeof(Student));

  strcpy(new_student->first_name, first_names[rand() % 24]);
  strcpy(new_student->last_name, last_names[rand() % 24]);

  for (int i = 0; i < 10; i++) new_student->id[i] = (char) ((rand() % 10) + 48);
  new_student->id[10] = '\0';

  for (int i = 0; i < grades; i++) 
  {
    add_grade(new_student, (double) (25 + (rand() % 75)));
  }

  return new_student;
}